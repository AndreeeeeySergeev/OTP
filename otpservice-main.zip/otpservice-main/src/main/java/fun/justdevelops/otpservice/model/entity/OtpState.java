package fun.justdevelops.otpservice.model.entity;

public enum OtpState {
    ACTIVE,
    EXPIRED,
    USED
}
