package fun.justdevelops.otpservice.model;

public enum Role {
    USER,
    ADMIN
}
