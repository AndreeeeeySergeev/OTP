package fun.justdevelops.otpservice.model.entity;

public enum ChannelType {
    SMS,
    EMAIL,
    TELEGRAM,
    FILE
}
